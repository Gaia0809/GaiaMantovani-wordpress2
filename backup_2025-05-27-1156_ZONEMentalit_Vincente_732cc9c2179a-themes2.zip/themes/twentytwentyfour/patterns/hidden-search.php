<?php
/**
 * Title: Search
 * Slug: twentytwentyfour/hidden-search
 * Inserter: no
 */
?>

<!-- wp:search {"label":"<?php echo esc_attr_x( 'Search', 'search form label', 'twentytwentyfour' ); ?>","showLabel":false,"buttonText":"<?php echo esc_attr_x( 'Search', 'search button text', 'twentytwentyfour' ); ?>","fontSize":"medium"} /-->
