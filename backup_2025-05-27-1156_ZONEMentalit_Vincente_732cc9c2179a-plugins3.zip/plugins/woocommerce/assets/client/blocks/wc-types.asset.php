<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'df3cbcae422855d48387');
