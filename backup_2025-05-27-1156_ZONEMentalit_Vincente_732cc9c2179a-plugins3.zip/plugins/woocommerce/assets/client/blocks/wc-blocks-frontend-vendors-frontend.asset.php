<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'a5f075e4ff6dd6090875');
