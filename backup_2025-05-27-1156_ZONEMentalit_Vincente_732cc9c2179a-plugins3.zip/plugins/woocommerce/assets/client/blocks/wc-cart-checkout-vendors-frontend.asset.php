<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'a16e7eb12f5267371fe0');
