<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'e4169377f115faded81a');
