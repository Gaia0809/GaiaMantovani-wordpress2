<?php return array('dependencies' => array('wp-polyfill'), 'version' => '13ca26913ccb282c047e');
