<?php return array('dependencies' => array('wp-api-fetch', 'wp-polyfill', 'wp-url'), 'version' => '0d3321630119e50d175f');
