<?php return array('dependencies' => array('react', 'wp-element', 'wp-polyfill'), 'version' => 'ce9125bf472706dea11a');
