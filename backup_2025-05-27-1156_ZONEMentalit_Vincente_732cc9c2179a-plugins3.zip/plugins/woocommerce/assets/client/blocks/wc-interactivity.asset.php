<?php return array('dependencies' => array('wp-polyfill'), 'version' => '4d6b4e91a3395b30b454');
