<?php return array('dependencies' => array('wp-polyfill'), 'version' => '2def9412eeabab2071b2');
