<?php return array('dependencies' => array('react', 'wc-settings', 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-interactivity', 'wp-polyfill'), 'version' => '082a09315b5142345249');
