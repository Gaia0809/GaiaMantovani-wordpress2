<?php return array('dependencies' => array('wp-hooks', 'wp-polyfill'), 'version' => '4d43a4bcb41a5a6336c2');
